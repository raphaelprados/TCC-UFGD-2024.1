#include "dmtcp.h"

// Defines NEXT_FNC_DEFAULT
// Needed to handle GNU symbol versioning.
#include "dmtcp_dlsym.h"
