#!/bin/bash

rm -Rf ckpt_* dmtcp_restart_* dmtcp_command.* hellompi_[cr].o* hellompi_[cr].e*
rm -Rf LOGS/*