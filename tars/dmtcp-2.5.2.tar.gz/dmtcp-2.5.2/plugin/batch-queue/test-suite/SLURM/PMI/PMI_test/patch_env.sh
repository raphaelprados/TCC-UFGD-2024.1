source ../../../dmtcp_env.sh
