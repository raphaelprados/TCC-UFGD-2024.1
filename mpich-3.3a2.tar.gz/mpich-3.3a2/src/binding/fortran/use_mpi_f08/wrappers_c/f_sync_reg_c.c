/* -*- Mode: C; c-basic-offset:4 ; indent-tabs-mode:nil ; -*- */
/*
 *  (C) 2014 by Argonne National Laboratory.
 *      See COPYRIGHT in top-level directory.
 */

#include "cdesc.h"

int MPIR_F_sync_reg_cdesc(CFI_cdesc_t* buf)
{
    int err = MPI_SUCCESS;

    /* Intentionally left empty */

    return err;
}
