This directory needs to exist in the repo so that the Autotools can
generate a file here.  We have a put a token file in this directory so
that git doesn't ignore the empty directory in the repository.
